import { Component, OnInit } from '@angular/core';
import { NavController, ModalController } from '@ionic/angular';
import { interval, Subject } from 'rxjs';
import { DataServiceService } from '../Data-service.service';
import { InputDialogServiceService } from '../input-dialog-service.service';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})



export class Tab2Page {
  constructor(public NavCtrl: NavController, public ModalCtrl: ModalController, public dataService: DataServiceService, public inputDialogService: InputDialogServiceService) {}

  async startTimer() {
    var index=0;
    console.log(index);
    //while (index<this.dataService.items.length) {
    
      //for (var item in this.dataService.items){
        //console.log(index);

          if (index<this.dataService.items.length) {
            const timeCount=interval(1000)
            timeCount.subscribe((d) => {
            console.log(d);
            if (this.dataService.items[index].time>0) {

              this.dataService.items[index].time=this.dataService.items[index].time-1;
              
              }else{
                index=index+1;
              }
            });
          }else{
            
          }
          
        
      //}
    //}
    
    
  }

  loadItems () {
    return this.dataService.getItems ();
  }
}


  





