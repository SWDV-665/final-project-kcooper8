import { Component, OnInit } from '@angular/core';
import { NavController, ModalController } from '@ionic/angular';
import { interval, Subject } from 'rxjs';
import { DataServiceService } from '../Data-service.service';
import { InputDialogServiceService } from '../input-dialog-service.service';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})



export class Tab2Page {
  constructor(public NavCtrl: NavController, public ModalCtrl: ModalController, public dataService: DataServiceService, public inputDialogService: InputDialogServiceService) {}

  async startTimer() {
    
    for (var index in this.dataService.items, index<=this.dataService.items.length, index=index+1){
      const obs$=interval(1000)
      obs$.subscribe((d) => {
        if (this.dataService.items[index].time>0) {
          this.dataService.items[index].time=this.dataService.items[index].time-1;
          }
        console.log(d);
      });
    }
    
    
  }

  loadItems () {
    return this.dataService.getItems ();
  }
}


  





