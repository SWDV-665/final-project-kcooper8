import { Injectable } from '@angular/core';
import { ToastController } from '@ionic/angular';
import { AlertController } from '@ionic/angular';
import { DataServiceService } from './Data-service.service';

@Injectable({
  providedIn: 'root'
})
export class InputDialogServiceService {

  constructor(public toastController: ToastController, public alertController: AlertController, public dataService: DataServiceService) {
    console.log('Hello InputDialogService');
   }
  

  async showPrompt (item ?, index ?) {
    const alert = await this.alertController.create({
      header: item ? 'Edit Item' : 'Add Item',
      message: item ? "Please edit item..." : "Please enter item...",
      inputs: [
        {
          name: 'exercise',
          type: 'text',
          placeholder: 'Exercise',
          value: item ? item.exercise : null
        },
        {
          name: 'time',
          type: 'text',
          placeholder: 'Time in Seconds',
          value: item ? item.time : null
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: item ? 'Edit':'Add',
          handler: item => {
            console.log('Confirm Edit/Add', item);
            if (index !== undefined) {
              this.dataService.editItem (item, index);
            }
            else this.dataService.addItem (item);
          }
        }
      ]
    });

    await alert.present();
  }


  async showBreakPrompt (item ?, index ?) {
    const alert = await this.alertController.create({
      header: item ? 'Edit Item' : 'Add Item',
      message: item ? "Please edit break time..." : "Please enter break time...",
      inputs: [
        {
          name: 'time',
          type: 'text',
          placeholder: 'Time in Seconds',
          value: item ? item.time : null
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: item ? 'Edit':'Add',
          handler: item => {
            console.log('Confirm Edit/Add', item);
            if (index !== undefined) {
              this.dataService.editItem (item, index);
            }
            else this.dataService.addItem (item);
          }
        }
      ]
    });

    await alert.present();
  }
}