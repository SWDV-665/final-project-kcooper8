
import { Component, OnInit } from '@angular/core';
import { NavController, ModalController } from '@ionic/angular';
import { interval, Subject } from 'rxjs';
import { DataServiceService } from '../Data-service.service';
import { InputDialogServiceService } from '../input-dialog-service.service';

import { NativeAudio } from '@awesome-cordova-plugins/native-audio/ngx';


@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})



export class Tab2Page {
 constructor(public NavCtrl: NavController, public ModalCtrl: ModalController, public dataService: DataServiceService, public inputDialogService: InputDialogServiceService, public nativeAudio: NativeAudio) {
  this.nativeAudio.preloadSimple('uniqueId1', 'src\assets\audio\Ding-sound-effect.mp3');
  this.nativeAudio.preloadComplex('uniqueId2', 'src\assets\audio\Ding-sound-effect.mp3', 1, 1, 0);

  this.nativeAudio.play('uniqueId1');

  // can optionally pass a callback to be called when the file is done playing
  this.nativeAudio.play('uniqueId1', () => console.log('uniqueId1 is done playing'));

  this.nativeAudio.loop('uniqueId2');

  this.nativeAudio.setVolumeForComplexAsset('uniqueId2', 0.6);

  this.nativeAudio.stop('uniqueId1');

  this.nativeAudio.unload('uniqueId1');
  } 

  async startTimer() {
    this.nativeAudio.play('uniqueId1', () => console.log('uniqueId1 is done playing'));
    var index=0;
    console.log(index);
    //while (index<this.dataService.items.length) {
    
      //for (var item in this.dataService.items){
        //console.log(index);

          if (index<this.dataService.items.length) {
            const timeCount=interval(1000)
            timeCount.subscribe((d) => {
            console.log(d);
            if (this.dataService.items[index].time>0) {

              this.dataService.items[index].time=this.dataService.items[index].time-1;
              
              }else{
                index=index+1;
              }
            });
          }else{
            
          }

    
  }

  loadItems () {
    return this.dataService.getItems ();
  }
}



  



  





