import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataServiceService {

  items = [];

  constructor() {
    console.log('Hello DataService')
   }

   removeItem(index) {
    this.items.splice(index, 1);
   }

   addItem (item) {
    this.items.push(item);
   }

   editItem (item, index) {
    this.items[index]=item;
   }

   getItems () {
    return this.items;3
    
   }
}

